#!/bin/sh
./kmeans_non_mpi 3 ./stars/stars-9.txt ./stars/stars-15.txt ./stars/stars-82.txt
