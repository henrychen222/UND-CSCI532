#!/bin/sh
gcc -o kmeans_non_mpi kmeans_non_mpi.c -lm -g
