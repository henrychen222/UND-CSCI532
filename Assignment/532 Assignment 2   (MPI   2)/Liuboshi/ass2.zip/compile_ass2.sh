#!/bin/sh
mpicxx -o ass2 main.cpp -std=c++11 -O3
