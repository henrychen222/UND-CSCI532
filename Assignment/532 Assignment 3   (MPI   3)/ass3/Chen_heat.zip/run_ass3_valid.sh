#!/bin/sh
./ass3_valid sim_test_valid 18 18 1 1 4
