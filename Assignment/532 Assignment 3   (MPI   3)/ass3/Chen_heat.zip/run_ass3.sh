#!/bin/sh
mpirun -np 16 ass3 --sim_name sim_test --height 16 --width 16 --v_slice 4 --h_slice 4 --time_step 4
