#!/bin/sh
mpicxx -o ass3_valid heat_diffusion.cxx -std=c++11 -O3
