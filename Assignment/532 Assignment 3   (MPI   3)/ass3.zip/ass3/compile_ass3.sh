#!/bin/sh
mpicxx -o ass3 heat_diffusion_mpi.cxx -std=c++11 -O3
