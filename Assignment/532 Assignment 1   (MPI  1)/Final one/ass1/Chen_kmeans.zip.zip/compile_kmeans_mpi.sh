#!/bin/sh
mpicc -o kmeans_mpi kmeans_mpi.c -lm
